import UIKit

class carparts{
    var engine: String = "V4"
    var color: String = "Yellow"
    var tint: String = "Carbon Tint"
    var upholstery: String = "Nylon"
    
    func customization(engine: String, color: String, tint: String, upholstery: String) -> String{
        return engine + color + tint + upholstery
    }
}
var design = carparts()
var car = design.customization(engine: "V4", color: "Yellow", tint: "Carbon Tint", upholstery: "Nylon")
